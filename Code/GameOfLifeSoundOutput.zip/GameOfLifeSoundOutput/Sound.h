volatile float sampleIndex = 0.0;
volatile float sampleIncrement = 2.0; // sets frequency of audio output
volatile float sampleVolume = 1.0; // full volume
// this defines the note intervals in the scale of C major
int8_t scale[] = { 0, 2, 4, 5, 7, 9, 11, 12 }; 

#define ENVELOPE_TABLE_LEN 256
volatile float envelope_table[ENVELOPE_TABLE_LEN]; 
volatile boolean hush = false;
volatile boolean stopNote = false;
int16_t waveTable [256];
int16_t noteDuration = 100; // length of note
int16_t noteSpace = 100; // length of space between notes
int16_t notesProduced = 0; // count of notes in a pattern
  
float midiNoteToIncrement(int8_t noteNumber){
  //for one cycle it will take of 5.80498866213x10^-2 seconds
  // so for 1 Hz need to move through table at 5.80498866213E-3 steps per timer call

  if(noteNumber < 0) noteNumber = 0;
  float frequency = 440.0  * pow(2, ((noteNumber - 69) / 12.0)); // 440.0 = Frequency 69 = note number of middle A  
  return frequency * 5.80498866213E-3; // 5.80498866213E-3 is the frequency to note increment constant
}
   
void generateTable(float fundamental, float harmonic2, float harmonic3, float harmonic4, float harmonic5){
  const float pi = 3.1415;
  float angle;
  float weighting[] = {fundamental, harmonic2, harmonic3, harmonic4, harmonic5};
  float maxAmplitude = fundamental + harmonic2 + harmonic3 + harmonic4 + harmonic5;
  float reduction = 0.01;
  
  while(maxAmplitude > 0.99) { // reduce harmonic weighting until they add up to 0.99
    for(int16_t i = 0; i<5; i++){
       weighting[i] = weighting[i]*(1.0 - reduction);
       if(weighting[i] < 0.0) weighting[i] = 0;
    }   
    maxAmplitude = 0;
    for(int16_t i = 0; i<5; i++){
       maxAmplitude += weighting[i]; 
      }
    }
  
  for(int16_t i = 0; i<256; i++){ // generate the waveform
    angle = ((2.0 * pi)) / (256.0 / (float)i);
    waveTable[i] = 0; // wipe any previous value in the table
    for(int16_t j = 0; j<5; j++){ // add the new sample point
    waveTable[i] += (int16_t)((2048 * weighting[j]) * sin(angle * (j+1))); // negative values will occur
    }
  } 
}

// callback ISR used by timer
void timer_callback(timer_callback_args_t __attribute((unused)) *p_args) {
  static int16_t lastSample = 0;
  if(hush) { *DAC12_DADR0 = 2048; return;}
  if(stopNote){ // reduce click when stopping a note by ramping up or down to mid point
    int16_t waveDirection = -1;
    if(lastSample < 2048) waveDirection = 1;
    *DAC12_DADR0 = lastSample + waveDirection;
    lastSample += waveDirection;
    if(lastSample ==2048) hush = true; // got to the mid point bias
    return; // don't produce more samples
  }
  // output the next sample
  sampleIndex += sampleIncrement; // update floating point index
  if(sampleIndex > 255.0) sampleIndex -= 255.0; // ensure wrap round with overshoot carried forward 
  lastSample = 2048 + (sampleVolume * waveTable[int16_t(sampleIndex)]);
  *DAC12_DADR0 = lastSample;   // DAC update DAC ignores top 4 bits    
} // end of callback ISR

bool beginTimer(float rate) {
  uint8_t timer_type = GPT_TIMER;
  int8_t tindex = FspTimer::get_available_timer(timer_type);
  if (tindex < 0){
    tindex = FspTimer::get_available_timer(timer_type, true);
  }
  if (tindex < 0){
    return false;
  }
  FspTimer::force_use_of_pwm_reserved_timer();
  if(!audio_timer.begin(TIMER_MODE_PERIODIC, timer_type, tindex, rate, 0.0f, timer_callback)){
    return false;
  }
  if (!audio_timer.setup_overflow_irq()){
    return false;
  }
  if (!audio_timer.open()){
    return false;
  }
  if (!audio_timer.start()){
    return false;
  }
  return true;
}

void setup_dac(void)       // Note make sure ADC is stopped before setup DAC
  {
  *MSTP_MSTPCRD &= ~(0x01 << MSTPD20);  // Enable DAC12 module
  *DAC12_DADPR    = 0x00;               // DADR0 Format Select Register - Set right-justified format
//  *DAC12_DAADSCR  = 0x80;             // D/A A/D Synchronous Start Control Register - Enable
  *DAC12_DAADSCR  = 0x00;               // D/A A/D Synchronous Start Control Register - Default
// 36.3.2 Notes on Using the Internal Reference Voltage as the Reference Voltage
  *DAC12_DAVREFCR = 0x00;               // D/A VREF Control Register - Write 0x00 first - see 36.2.5
  *DAC12_DADR0    = 0x0000;             // D/A Data Register 0 
   delayMicroseconds(10);               // Needed delay - see data sheet
  *DAC12_DAVREFCR = 0x01;               // D/A VREF Control Register - Select AVCC0/AVSS0 for Vref
  *DAC12_DACR     = 0x5F;               // D/A Control Register - 
   delayMicroseconds(5);                // Needed delay - see data sheet
  *DAC12_DADR0    = 2048;               // D/A Data Register 0 - value of mid range bias  
  *PFS_P014PFS   = 0x00000000;          // Port Mode Control - Make sure all bits cleared
  *PFS_P014PFS  |= (0x1 << 15);         // ... use as an analog pin
  }
