// grid dimensions
#define MAX_Y 8
#define MAX_X 12

// time to wait between turns
#define TURN_DELAY 200

// how many turns per game before starting a new game
// you can also use the reset button on the board
#define TURNS_MAX 60

// number of patterns in predefined list
#define MAX_PATTERNS 5

// how many turns to wait if there are no changes before starting a new game
#define NO_CHANGES_RESET 3

int16_t turns = 0;            // counter for turns
int16_t noChanges = 0;        // counter for turns without changes
boolean newPattern = true;    // do we have a new pattern

// game state. 0 is dead cell, 1 is live cell
uint8_t grid[MAX_Y][MAX_X] = {
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
};

int16_t currentPattern = 4;

String patternNames[] = {
  "Glider",
  "Light-weight spaceship",
  "R-Pentomino",
  "Diehard",
  "Glider Crash"
};

// display the current grid to the LED matrix
void displayGrid() {
  matrix.renderBitmap(grid, 8, 12);
}

// custom starting grid patterns
boolean cGrids[][MAX_Y][MAX_X] = {
    { /* Glider */
        {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    },
    { /* Light-weight spaceship */
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0},
        {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0},
        {0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    },
    { /* R-Pentomino */
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    },
    { /* Die hard */
        {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0},
        {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    },
    { /* Crash */
        {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    }
};


// update the current grid from the new grid and count how many changes occurred 
// count the number of neighbour live cells for a given cell
int16_t countNeighbours(int16_t y, int16_t x) {
  int16_t count = 0;

  // -- Row above us ---
  if (y > 0) {
    // above left
    if (x > 0) {
      count += grid[y - 1][x - 1];
    }
    // above
    count += grid[y - 1][x];
    // above right
    if ((x + 1) < MAX_X) {
      count += grid[y - 1][x + 1];
    }
  }

  // -- Same row -------
  // left
  if (x > 0) {
    count += grid[y][x - 1];
  }
  // right
  if ((x + 1) < MAX_X) {
    count += grid[y][x + 1];
  }

  // -- Row below us ---
  if ((y + 1) < MAX_Y) {
    // below left
    if (x > 0) {
      count += grid[y + 1][x - 1];
    }
    // below
    count += grid[y + 1][x];
    // below right
    if ((x + 1) < MAX_X) {
      count += grid[y + 1][x + 1];
    }
  }

  return count;
}

// reset the grid
void resetGrid() {
  Serial.print("Current pattern: ");
  Serial.println(patternNames[currentPattern]);
  noChanges = 0;
  turns = 0;
  newPattern = true; 
  for (int16_t y = 0; y < MAX_Y; y++) {
    for (int16_t x = 0; x < MAX_X; x++) {
      grid[y][x] = cGrids[currentPattern][y][x];
    }
  }
  currentPattern++;
  if(currentPattern >= MAX_PATTERNS){
    currentPattern = 0;
  }
  displayGrid();
}

void playGoL() {
  /*
    1. Any live cell with fewer than two neighbours dies, as if by loneliness.
    2. Any live cell with more than three neighbours dies, as if by
    overcrowding.
    3. Any live cell with two or three neighbours lives, unchanged, to the next
    generation.
    4. Any dead cell with exactly three neighbours comes to life.
    */
  newPattern = false;
  boolean newGrid[MAX_Y][MAX_X] = {
      {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
      {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
      {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
      {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
      {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
      {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
      {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
      {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
  };
  
  for (int16_t y = 0; y < MAX_Y; y++) {
    for (int16_t x = 0; x < MAX_X; x++) {
      int16_t neighbours = countNeighbours(y, x);
      if (grid[y][x] == 1) {
        if ((neighbours == 2) || (neighbours == 3)) {
          newGrid[y][x] = 1;
        } else {
          newGrid[y][x] = 0;
        }
      } else {
        if (neighbours == 3) {
          newGrid[y][x] = 1;
        } else {
          newGrid[y][x] = 0;
        }
      }
    }
  }

  int16_t changes = 0;
  for (int16_t y = 0; y < MAX_Y; y++) {
    for (int16_t x = 0; x < MAX_X; x++) {
      if (newGrid[y][x] != grid[y][x]) {
        changes++;
      }
      grid[y][x] = newGrid[y][x];
    }
  }

  // update global counter when no changes occurred
  if (changes == 0) {
    noChanges++;
  }
}
